package DayOne;

public class RandomNumber {
    public static void main(String[] args) {
        double RandomNumber = Math.floor(Math.random()*10)%6;
        System.out.println("Random number below 6 is "+ RandomNumber);
    }
}
