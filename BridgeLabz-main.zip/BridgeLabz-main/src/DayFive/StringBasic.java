package DayFive;

public class StringBasic {
    public static void main(String[] args) {
        String s = "Aftab";
        System.out.println("Original String is "+ s);
        System.out.println("upper case string is "+s.toUpperCase());
        System.out.println("lower case string is "+s.toLowerCase());
    }
}
