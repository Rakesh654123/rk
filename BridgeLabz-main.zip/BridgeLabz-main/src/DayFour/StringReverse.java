package DayFour;

public class StringReverse {
    public static void main(String[] args) {
        String name = "BridgeLabz";
        StringBuilder  s = new StringBuilder(name);
        System.out.println(s.reverse());
    }
}
