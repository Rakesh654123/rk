from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    name = "World!" # chnge this to your name 
    return "Hello"+ name # return string the hhello and name 
    
if __name__ == '__main__':
    app.run(debug=True)