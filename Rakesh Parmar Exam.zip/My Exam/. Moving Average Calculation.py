import pandas as pd
import numpy as np 
def average(data,window_size= 7):
    data_series = pd.Series(data) # covert all the the data in panda series
    moving_avg = data_series.rolling(window=window_size).mean() #calculate the moving average
    return moving_avg.tolist()