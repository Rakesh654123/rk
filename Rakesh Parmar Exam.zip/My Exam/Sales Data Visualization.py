import matplotlib.pyplot as plt 

def plot_sales(sales_data):
    
    dates = [sale['date'] for sale in sales_data]
    amounts = [sale['amount'] for sale in sales_data]
    
    plt.figure(figsize =(10,5)) #width and hight of the plot
    plt.plot(dates,amounts,marker = 'o') #plot the data
    plt.title('Sales Data over a time') # title for the plot
    plt.xlabel('Date') #x axis label
    plt.ylabel('Sales Amount')#y axis label
    plt.grid(True)#here show the gid in the plot
    plt.show()
    

