def is_palidrome_check(Sentence):
    Sentence = Sentence.lower().replace(" ", "") #remove space and convert to lover case
    return Sentence == Sentence[::-1] #compare the string to the reverse of a string

print(is_palidrome_check(" I am going in wait for my call"))