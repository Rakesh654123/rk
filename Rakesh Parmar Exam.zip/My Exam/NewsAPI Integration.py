import requests 
def fetch_topnews(api_key):
    url = f'https://newsapi.org/v2/everything?q=Apple&from=2024-06-15&sortBy=popularity&apiKey=96dbed3f241e49e285be19ec26058964' #url for fetching to the news
    response = requests.get(url) #getting response from the url
    articles = response.json().get('articles',[]) #getting aryticlee from the response
    
    for i , article in enumerate(articles[:5]): #here is the loop for getting top news
        print(f"{i+1}.{article['title']}")