def total_sales(sales_data):
    return sum(sale['amount'] for sale in sales_data) # sum of all sales amount