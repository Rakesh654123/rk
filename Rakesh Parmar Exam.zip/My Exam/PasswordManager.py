import random
import string

class PasswordManager:
    def __init__(self):
        self.passwords = {}
        
    def add_password(self, service,password):
        self.passwords[service]= password #here is add the password in dictionary
    def retrieve_pass(self,service):
        return self.passwords.get(service)#hers get the password from the dictionary
    def delete_pass(self,service):
        if service in self.passwords: #here is the check the service aare pressnt in dicytionary or not
            del self.passwords[service]
    def generate_random(self,length=9):
        character = string.ascii_letters + string.digits + string.punctuation
        return ''.join(random.choice(character)for _ in range(length))#generate the random password